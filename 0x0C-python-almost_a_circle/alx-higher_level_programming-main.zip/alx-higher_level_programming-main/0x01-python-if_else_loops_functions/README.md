# Python - if/else, loops, functions
Foundations - Higher-level programming ― Python
