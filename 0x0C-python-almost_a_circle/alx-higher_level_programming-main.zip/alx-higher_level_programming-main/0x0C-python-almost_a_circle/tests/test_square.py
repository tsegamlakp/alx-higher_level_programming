#!/usr/bin/python3
"""Unit test class Square"""
import unittest
from models.square import Square
import sys
from io import StringIO
