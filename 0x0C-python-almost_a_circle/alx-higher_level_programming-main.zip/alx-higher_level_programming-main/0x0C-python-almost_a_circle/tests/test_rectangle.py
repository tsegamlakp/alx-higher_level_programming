#!/usr/bin/python3
"""Unit test class Rectangle"""
import unittest
import json
import sys
import os
from models.rectangle import Rectangle
