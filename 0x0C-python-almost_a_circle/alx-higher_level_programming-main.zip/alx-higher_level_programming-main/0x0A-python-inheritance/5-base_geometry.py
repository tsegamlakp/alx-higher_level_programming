#!/usr/bin/python3
"""
    5-base_geometry: class BaseGeometry
"""


class BaseGeometry:
    """
        An empty class.
    """
    pass
